﻿namespace SistemaCadastro
{
    partial class TelaLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaLogin));
            lblEmail = new Label();
            lblSenha = new Label();
            txtEmail = new TextBox();
            txtSenha = new TextBox();
            btnEntrar = new Button();
            llblEsqueciSenha = new LinkLabel();
            llblCadastrar = new LinkLabel();
            SuspendLayout();
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmail.Location = new Point(48, 65);
            lblEmail.Margin = new Padding(4, 0, 4, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(62, 19);
            lblEmail.TabIndex = 0;
            lblEmail.Text = "E-mail:";
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(48, 113);
            lblSenha.Margin = new Padding(4, 0, 4, 0);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(64, 19);
            lblSenha.TabIndex = 1;
            lblSenha.Text = "Senha:";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(120, 62);
            txtEmail.Margin = new Padding(4);
            txtEmail.MaxLength = 100;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(251, 26);
            txtEmail.TabIndex = 1;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(120, 110);
            txtSenha.Margin = new Padding(4);
            txtSenha.MaxLength = 8;
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '*';
            txtSenha.Size = new Size(251, 26);
            txtSenha.TabIndex = 2;
            // 
            // btnEntrar
            // 
            btnEntrar.Location = new Point(184, 159);
            btnEntrar.Margin = new Padding(4);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(129, 35);
            btnEntrar.TabIndex = 3;
            btnEntrar.Text = "Entrar";
            btnEntrar.UseVisualStyleBackColor = true;
            btnEntrar.Click += btnEntrar_Click;
            // 
            // llblEsqueciSenha
            // 
            llblEsqueciSenha.AutoSize = true;
            llblEsqueciSenha.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            llblEsqueciSenha.Location = new Point(184, 212);
            llblEsqueciSenha.Margin = new Padding(4, 0, 4, 0);
            llblEsqueciSenha.Name = "llblEsqueciSenha";
            llblEsqueciSenha.Size = new Size(113, 16);
            llblEsqueciSenha.TabIndex = 4;
            llblEsqueciSenha.TabStop = true;
            llblEsqueciSenha.Text = "Esqueci a Senha";
            llblEsqueciSenha.LinkClicked += llblEsqueciSenha_LinkClicked;
            // 
            // llblCadastrar
            // 
            llblCadastrar.AutoSize = true;
            llblCadastrar.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            llblCadastrar.Location = new Point(200, 243);
            llblCadastrar.Margin = new Padding(4, 0, 4, 0);
            llblCadastrar.Name = "llblCadastrar";
            llblCadastrar.Size = new Size(86, 16);
            llblCadastrar.TabIndex = 5;
            llblCadastrar.TabStop = true;
            llblCadastrar.Text = "Cadastrar-se";
            llblCadastrar.LinkClicked += llblCadastrar_LinkClicked;
            // 
            // TelaLogin
            // 
            AutoScaleDimensions = new SizeF(10F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(427, 293);
            Controls.Add(llblCadastrar);
            Controls.Add(llblEsqueciSenha);
            Controls.Add(btnEntrar);
            Controls.Add(txtSenha);
            Controls.Add(txtEmail);
            Controls.Add(lblSenha);
            Controls.Add(lblEmail);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "TelaLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tela Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblEmail;
        private Label lblSenha;
        private TextBox txtEmail;
        private TextBox txtSenha;
        private Button btnEntrar;
        private LinkLabel llblEsqueciSenha;
        private LinkLabel llblCadastrar;
    }
}
