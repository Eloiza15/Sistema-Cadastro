﻿namespace SistemaCadastro
{
    partial class EsqueciSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EsqueciSenha));
            lblEmail = new Label();
            lblNovaSenha = new Label();
            txtEmail = new TextBox();
            txtNovaSenha = new TextBox();
            btnRedefinirSenha = new Button();
            SuspendLayout();
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(101, 74);
            lblEmail.Margin = new Padding(4, 0, 4, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(62, 19);
            lblEmail.TabIndex = 0;
            lblEmail.Text = "E-mail:";
            // 
            // lblNovaSenha
            // 
            lblNovaSenha.AutoSize = true;
            lblNovaSenha.Location = new Point(55, 123);
            lblNovaSenha.Name = "lblNovaSenha";
            lblNovaSenha.Size = new Size(108, 19);
            lblNovaSenha.TabIndex = 1;
            lblNovaSenha.Text = "Nova Senha:";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(188, 71);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(206, 26);
            txtEmail.TabIndex = 1;
            // 
            // txtNovaSenha
            // 
            txtNovaSenha.Location = new Point(188, 120);
            txtNovaSenha.Name = "txtNovaSenha";
            txtNovaSenha.Size = new Size(206, 26);
            txtNovaSenha.TabIndex = 2;
            // 
            // btnRedefinirSenha
            // 
            btnRedefinirSenha.Location = new Point(153, 191);
            btnRedefinirSenha.Name = "btnRedefinirSenha";
            btnRedefinirSenha.Size = new Size(141, 23);
            btnRedefinirSenha.TabIndex = 3;
            btnRedefinirSenha.Text = "Redefinir Senha";
            btnRedefinirSenha.UseVisualStyleBackColor = true;
            btnRedefinirSenha.Click += btnRedefinirSenha_Click;
            // 
            // EsqueciSenha
            // 
            AutoScaleDimensions = new SizeF(10F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(466, 277);
            Controls.Add(btnRedefinirSenha);
            Controls.Add(txtNovaSenha);
            Controls.Add(txtEmail);
            Controls.Add(lblNovaSenha);
            Controls.Add(lblEmail);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "EsqueciSenha";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EsqueciSenha";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblEmail;
        private Label lblNovaSenha;
        private TextBox txtEmail;
        private TextBox txtNovaSenha;
        private Button btnRedefinirSenha;
    }
}