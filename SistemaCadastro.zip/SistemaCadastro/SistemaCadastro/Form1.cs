namespace SistemaCadastro
{
    public partial class TelaLogin : Form
    {
        public TelaLogin()
        {
            InitializeComponent();
        }

        private void llblCadastrar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TelaCadastro telaCadastro = new TelaCadastro(this);
            telaCadastro.Show();
            this.Hide();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtEmail.Text.Equals("") && !txtSenha.Text.Equals(""))
                {
                    Usuarios usuario = new Usuarios();
                    usuario.Email = txtEmail.Text;
                    usuario.Senha = txtSenha.Text;

                    if (Usuarios.verificarEmail(txtEmail.Text))
                    {
                        if (usuario.verificarLogin())
                        {
                            MessageBox.Show("Login realizado com sucesso!");
                            string nomeLogado = usuario.BuscarNome();
                            TelaSistema sistema = new TelaSistema(nomeLogado, this);
                            sistema.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Usu�rio ou Senha inv�lidos!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Forne�a um e-mail v�lido!");
                    }
                }
                else
                {
                    MessageBox.Show("Preencha os campos corretamente!");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("N�o foi poss�vel acessar o sistema " + ex.Message);
            }
        }

        private void llblEsqueciSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            EsqueciSenha esqueciSenha = new EsqueciSenha();
            esqueciSenha.Show();
            this.Hide();
        }
    }
}
