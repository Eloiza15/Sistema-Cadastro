﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaCadastro
{
    public partial class TelaCadastro : Form
    {
        private Form telaLogin;
        public TelaCadastro(Form tela)
        {
            InitializeComponent();
            telaLogin = tela;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtNome.Text.Equals("") && !txtEmail.Text.Equals("") && !txtSenha.Text.Equals(""))
                {
                    Usuarios usuario = new Usuarios();
                    usuario.Nome = txtNome.Text;
                    usuario.Email = txtEmail.Text;
                    usuario.Senha = txtSenha.Text;

                    if (Usuarios.verificarEmail(txtEmail.Text))
                    {
                        if (usuario.CadastrarUsuario())
                        {
                            MessageBox.Show("Cadastro Realizado");
                        }
                        else
                        {
                            MessageBox.Show("Falha ao cadastrar usuário");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Favor inserir um E-mail válido!");
                    }
                }
                else
                {
                    MessageBox.Show("Preencha os campos corretamente!");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao cadastrar usuário: " + ex.Message);
            }
        }

        private void TelaCadastro_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
