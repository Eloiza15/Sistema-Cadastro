﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaCadastro
{
    public partial class TelaSistema : Form
    {
        private string nomeUsuario;
        private Form telaLogin;
        public TelaSistema(string nome, Form tela)
        {
            InitializeComponent();
            nomeUsuario = nome;
            telaLogin = tela;
        }
        private void TelaSistema_Load(object sender, EventArgs e)
        {
            lblNomeUsuario.Text = "Bem vindo, " + nomeUsuario + "!";
        }

        private void TelaSistema_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
