﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaCadastro
{
    public partial class EsqueciSenha : Form
    {
        public EsqueciSenha()
        {
            InitializeComponent();
        }

        private void btnRedefinirSenha_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtEmail.Text.Equals("") && !txtNovaSenha.Text.Equals(""))
                {
                    Usuarios usuarios = new Usuarios();
                    usuarios.Email = txtEmail.Text;
                    usuarios.Senha = txtNovaSenha.Text;

                    if(Usuarios.verificarEmail(txtEmail.Text))
                    {
                        if(usuarios.RedefinirSenha())
                        {
                            MessageBox.Show("Senha atuaizada com sucesso");
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível atuaizar a senha");
                        }
                    }
                    else
                    {
                        MessageBox.Show("E-mail inválido");
                    }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao redefinir senha! " + ex.Message);
            }
        }
    }
}
